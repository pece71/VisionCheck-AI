import base64
import json
import cv2
import numpy as np

DEFAULTS = {"sharpness": 45, "bright": 210, "dark": 55, "contrast": 45, "exposure": 50}


def normalize_score(value, minimum, maximum):
    if value <= minimum: return 0.0
    if value >= maximum: return 100.0
    return 100.0 * (value - minimum) / (maximum - minimum)


def analyze_image_bytes(data: bytes):
    arr = np.frombuffer(data, dtype=np.uint8)
    image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("Invalid or unsupported image")
    h, w = image.shape[:2]
    if w > 1000:
        scale = 1000 / w
        image = cv2.resize(image, (1000, int(h * scale)), interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    total = gray.size
    lap = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    sharpness = normalize_score(lap, 25, 300)
    raw_brightness = float(np.mean(gray))
    if 75 <= raw_brightness <= 190: brightness = 100.0
    elif raw_brightness < 75: brightness = max(0.0, raw_brightness/75.0*100.0)
    else: brightness = max(0.0, 100.0 - ((raw_brightness-190.0)/65.0)*100.0)
    contrast = normalize_score(float(np.std(gray)), 15, 65)
    clipped = (float(np.sum(gray < 20)) + float(np.sum(gray > 235))) / total * 100.0
    exposure = max(0.0, 100.0 - clipped*3.0)
    mp = (w*h)/1_000_000.0
    resolution = 100.0 if mp >= 2 else 80.0 if mp >= 1 else 60.0 if mp >= 0.5 else 40.0
    overall = sharpness*.30 + brightness*.20 + contrast*.20 + exposure*.20 + resolution*.10

    t = DEFAULTS
    if sharpness < t["sharpness"]: result = "BLURRED"
    elif raw_brightness < t["dark"]: result = "TOO DARK"
    elif raw_brightness > t["bright"]: result = "TOO BRIGHT"
    elif contrast < t["contrast"]: result = "LOW CONTRAST"
    elif exposure < t["exposure"]: result = "POOR EXPOSURE"
    elif resolution < 60: result = "LOW RESOLUTION"
    else: result = "CLEAR"

    return {
        "opencv_version": cv2.__version__,
        "sharpness": round(sharpness, 2), "brightness": round(brightness, 2),
        "contrast": round(contrast, 2), "exposure": round(exposure, 2),
        "resolution": round(resolution, 2), "visioncheck_score": round(overall, 2),
        "result": result
    }


def handler(event, _context):
    try:
        body = event.get("body", event)
        if isinstance(body, str):
            body = json.loads(body)
        image_b64 = body.get("image_base64")
        if not image_b64:
            return {"statusCode": 400, "headers": {"content-type": "application/json"},
                    "body": json.dumps({"error": "image_base64 is required"})}
        result = analyze_image_bytes(base64.b64decode(image_b64))
        return {"statusCode": 200, "headers": {"content-type": "application/json"}, "body": json.dumps(result)}
    except Exception as exc:
        return {"statusCode": 500, "headers": {"content-type": "application/json"},
                "body": json.dumps({"error": str(exc), "opencv_version": cv2.__version__})}
